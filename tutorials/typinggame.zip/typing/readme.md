
Credits

https://www.flaticon.com/packs/farming-and-gardening-5?k=1611544381586#

Rabbit - https://www.flaticon.com/free-icon/rabbit_1581577?related_id=1581577
Goat - https://www.flaticon.com/free-icon/goat_862844?term=goat&related_id=862844
Sheep - https://www.flaticon.com/free-icon/sheep_3570618?term=sheep&related_id=3570618
Alpaca - https://www.flaticon.com/free-icon/llama_375056?term=llama&page=2&position=29&page=2&position=29&related_id=375056&origin=search
Camel - https://www.flaticon.com/free-icon/camel_882952?term=camel&page=1&position=54&page=1&position=54&related_id=882952&origin=search
Bison - https://www.flaticon.com/free-icon/bison_427554?term=bison&page=1&position=4&page=1&position=4&related_id=427554&origin=search
Muskox - https://pixabay.com/vectors/buffalo-musk-ox-horns-fur-mammal-5482440/
Woolly Mammoth - https://www.vecteezy.com/vector-art/109088-vector-ice-age-animals

Grass
https://www.vectorstock.com/royalty-free-vector/seamless-grass-texture-vector-12308819